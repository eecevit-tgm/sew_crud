<template>
	<div class="hello">
		<div v-for="student in students" :key="student">
			{{ student.email }}
		</div>
	</div>
</template>  
  
<script>  
import axios from 'axios'
export default {
	name: 'HelloWorld',
	data () {
		return {
			students: null,
		}
	},
	methods:{
		getStudents() {
			const path = 'http://localhost:5000/user';
			axios.get(path).then((res) => {
				this.students = res.data;
			}).catch((error) => {
				console.error(error);
			});
		},
		created(){
			this.getStudents()
		}
	}
}
</script>